class Server {
	public String type;
	public int id;
	public int state;
	public int available_time;
	public int cores;
	public int memory;	
	public int disk;

	public Server(String t, int i, int s, int at, int c, int m, int d) { //Primary Constructor
		type = t;
		id = i;
		state = s;
		available_time = at;
		cores = c;
		memory = m;
		disk = d;
	}

	public Server(final String rescDataMessage) { //Primary constructor
		
		String[] servStrings = rescDataMessage.split(" "); // Seperates message into array of strings split every <Space> character
		
		/* SERVER MESSAGE

		juju 0 0 84 2 4000 16000
		| | | | | | |
		| | | | | | +--- disk space
		| | | | | +--- memory
		| | | | +--- #CPU cores
		| | | +--- available time
		| | +--- server state
		| +--- server id of type small
		+--- server type

		*/

		type = servStrings[0];
		id = Integer.parseInt(servStrings[1]);
		state = Integer.parseInt(servStrings[2]);
		available_time = Integer.parseInt(servStrings[3]);
		cores = Integer.parseInt(servStrings[4]);
		memory = Integer.parseInt(servStrings[5]);
		disk = Integer.parseInt(servStrings[6]);
	}

	public Server() { //Blank Constructor
		type = "";
		id = -1;	// NEGATIVE ID = INVALID SERVER
		state = 0;
		available_time = 0;
		cores = 0;
		memory = 0;
		disk = 0;
	}

	public String getStringServer() {
		return this.type + " " + Integer.toString(this.id);
	}

	public Boolean hasResourcesToRunJob(Job j) {

		if(this.cores >= j.CPU_cores &&
		this.memory >= j.memory &&
		this.disk >= j.disk) {
			return true;
		}

		return false;
	}

	public int calculateFitnessValForJob(Job j) {
		return this.cores - j.CPU_cores;
		//difference	between	the	number	of	cores	the	job	requires	and	that	in	the	server
	}

}

 

 
