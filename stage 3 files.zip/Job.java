class Job {
	/* 
	JOBN	submit_time	(int)	job_ID	(int) estimated_runtime	(int)	#CPU_cores (int)	memory	(int)	disk	(int)
	*/
	public Integer submit_time;
	public Integer job_ID;
	public Integer estimated_runtime;
	public Integer CPU_cores;
	public Integer memory;
	public Integer disk;	

	public Job(int st, int jID, int rt, int co, int mem, int d) { //Primary constructor
		submit_time = st;
		job_ID = jID;
		estimated_runtime = rt;
		CPU_cores = co;
		memory = mem;
		disk = d;
	}

	public Job() { //Blank Constructor
		submit_time = 0;
		job_ID = -1; 				//ID -1 means invalid job
		estimated_runtime = 0;
		CPU_cores = 0;
		memory = 0;
		disk = 0;
	}

	public Job(String msg) {
		final String[] jobStrings = msg.split(" ");
		//jobStrings[0] equals "JOBN"
		submit_time = Integer.parseInt(jobStrings[1]);
		job_ID = Integer.parseInt(jobStrings[2]);
		estimated_runtime = Integer.parseInt(jobStrings[3]);
		CPU_cores = Integer.parseInt(jobStrings[4]);
		memory = Integer.parseInt(jobStrings[5]);
		disk = Integer.parseInt(jobStrings[6]);
	}

	public String toString() {
		return "JOB: sumit_time: " + Integer.toString(submit_time) 
		+ " Job_ID: " + Integer.toString(job_ID) 
		+ " estimated_runtime: " + Integer.toString(estimated_runtime) 
		+ " CPU_Cores: " + Integer.toString(CPU_cores) 
		+ " Memory: " + Integer.toString(memory) 
		+ " Disk: " + Integer.toString(disk);    
   }
}