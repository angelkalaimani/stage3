// File Name GreetingClient.java
import java.net.*;
import java.util.ArrayList;
import java.io.*;
import org.w3c.dom.*;

import javax.print.attribute.standard.Severity;
import javax.xml.parsers.*;
import java.io.*;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

public class GreetingClient {

    public static DataOutputStream out;
    public static Socket client;
    public static OutputStream outToServer;
    public static InputStream inFromServer;
    public static DataInputStream in;
    public static String schedulingAlgorithim;
    static ArrayList<ServerType> systemXML_servers = new ArrayList<ServerType>();
    static ArrayList<Server> servers = new ArrayList<Server>();
    public static ServerType largestServer = new ServerType();
    public static String bestServer = "";
    public static Job currentJob;

    public static void main(final String[] args) {

        final String serverName = "localhost";
        final int port = 50000;
        String currentMsg = "";
        int okCnt = 0;
        int jobCnt = 0;
        int rescDataCnt = 0;
        boolean AutheticationCheck = false;
        boolean ConnectionCheck = false;

        if (args.length >= 2) {
            schedulingAlgorithim = args[1];
        } else {
            schedulingAlgorithim = "allToLargest";
        }

        System.out.println("RUNNING USING: " + schedulingAlgorithim + " algorithim");
        try {
            System.out.println("Connecting to " + serverName + " on port " + port);
            initiliseSocketConnection(serverName, port);
            System.out.println("Just connected to " + client.getRemoteSocketAddress());

            // -------------------------------------//
            // ------------- Main Loop -------------//
            // -------------------------------------//

            sendMsg("HELO"); // Sends Initail Message To Server
            // Loop Executes Until "QUIT" Is Recived
            while (true) {

                if(currentMsg.equals("QUIT"))
                    break;

                currentMsg = readMsg();

                if (currentMsg.length() > 0) { // There is a message

                    // ---------- Print The Message --------//
                    System.out.print("RCVD: ");
                    System.out.println(currentMsg);
                    // -------------------------------------//

                    if (currentMsg.equals("OK")) {
                        okCnt = okCnt + 1; // Increment a counter for how many "ok's" have been received
                        if (okCnt == 1) { // If the first ok
                            sendMsg("AUTH GROUP15"); // AUTHENTICATE AS PER PROTOCOL
                        } else if (okCnt == 2) { // IF the second ok

                            loadSysXML();
                            largestServer = getLargestServerFromSysXML();

                            sendMsg("REDY"); // Tell Server The Client Is Ready For A Job
                        } else if (okCnt >= 3) {                            
                            sendMsg("REDY");
                        }
                    } else if (currentMsg.contains("JOB")) { // If A Job Is Recived...

                        System.out.println("RECIEVED A JOB!!!");
                        currentJob = new Job(currentMsg);
                        sendMsg("RESC All " + Integer.toString(currentJob.CPU_cores) + " " + Integer.toString(currentJob.memory) + " " + Integer.toString(currentJob.disk));
                        //sendMsg("RESC Avail " + Integer.toString(currentJob.CPU_cores) + " " + Integer.toString(currentJob.memory) + " " + Integer.toString(currentJob.disk));

                    } else if (currentMsg.equals("NONE")) { // No More Jobs To Be Scheduled...

                        System.out.println("NO More Jobs Left");
                        sendMsg("QUIT"); // Safley shutdown server as per protocol

                    } else if (currentMsg.equals("DATA")) { // If DATA received

                        System.out.println("Data Received ...");
                        sendMsg("OK"); // Send OK to tell server you are ready to accept DATA

                    } else if (currentMsg.equals(".")) { // If "." received

                        System.out.println("RESC FINISHED");
                        rescDataCnt = 0;

                        sendMsg("SCHD " + jobCnt + " " + getBestServer()); // SCHEDULE THE JOB TO THE FIRST INSTANCE (0)
                        jobCnt = jobCnt + 1; // Incriment A Job Count Variable
                        //sendMsg("REDY"); // Send ready to tell server the DATA was succesfuly received
                        // and now ready to schedule jobs

                    } else if (currentMsg.equals("QUIT")) { // If Quit Received, break the loop

                        System.out.println("Recieved Quit... Quitting Now...");

                        break;

                    } else {
                        if (currentMsg.contains("ERR")) {
                            break;
                        }
                        if (rescDataCnt == 0) {
                            servers.clear();                            
                        }
                        servers.add(new Server(currentMsg));
                        rescDataCnt++;
                        sendMsg("OK");  // If the message does not meet any of the above criteria, it is sendin            
                    }                    // Resource Data, so respond with "OK"
                }
                currentMsg = ""; // Reset Varaible
            }
            // -------------------------------------//
            // ---------- END MAIN LOOP ------------//
            // -------------------------------------//

            //Shut Down Client
            System.out.println("FINISHED");
            stopSocketConnection();

        } catch (final IOException e) {
            e.printStackTrace(); // CATCH IO EXCEPTIONS AND PRINT
        }
    }

    // GETS THE BEST SERVER - FOR FUTURE STAGES THIS WILL IMPLEMENT SOME FORM OF
    // CLEAVER ALGORITHIM...
    // FOR NOW JUST RETURNS ALL_TO_LARGE
    public static String getBestServer() {

        if (schedulingAlgorithim.equals("ff")) {

            return firstFit().getStringServer();

        } else if (schedulingAlgorithim.equals("wf")) {

            return worstFit().getStringServer();

        } else if (schedulingAlgorithim.equals("bf")) {

            return bestFit().getStringServer();
        }
        else if (schedulingAlgorithim.equals("sjf")){

            return sjf().getStringServer();

        } else if (schedulingAlgorithim.equals("allToLargest")) {

            return largestServer.type + " 0";

        } else {
            return "";
        }
    }

    // -------------------------------------//
    // -------- FIRST FIT ALGORITHM --------//
    // -------------------------------------//
    public static Server firstFit() { //ANGEL KALAIMANI 44625693
        /* ----- FIRST FIT PSUDO CODE -----//
            For a given job ji,
                1. Obtain server state information
                2. For each server type i, si , from the smallest to the largest
                    3. For each server j, si,j of server type si, from 0 to limit - 1 // j is server ID
                        4. If server si,j has sufficient available resources to run job ji then
                            5. Return si,j
                        6. End If
                    7. End For
                8. End For
                9. Return the first Active server with sufficient initial resource capacity to run job ji

         */


        System.out.println("");
        System.out.println("------- FIRST FIT ALGORITHIM ------");
        System.out.println("");

        System.out.println("CURRENT JOB: ");
        System.out.println(currentJob.toString());
        System.out.println("");

        System.out.println("AVAILABLE SERVERS");
        for (Server tempS : servers) {
            System.out.println(tempS.getStringServer());
        }
        System.out.println("");

        System.out.println("SERVERS IN SYSTEM.XML");
        for (ServerType tempST : systemXML_servers) {
            System.out.println(tempST.toString());
        }
        System.out.println("");
        System.out.println("----- END FIRST FIT ALGORITHIM -----");
        System.out.println("");


        for (ServerType servType : systemXML_servers) {

            servType.serversOfThisType.clear();

            for (Server tempS : servers) {
                if (tempS.type.equals(servType.type)) {
                    servType.serversOfThisType.add(tempS);
                }     
            }

        }

        Server firstFitServer = null;
        //Server firstFitServer = sortByID(systemXML_servers);

        for (ServerType tempST : systemXML_servers) {            
            for(int j = 0; j < tempST.limit -1; j++) {        //j is the server id

                if (tempST.serversOfThisType.get(j).hasResourcesToRunJob(currentJob)) {

                    System.out.println("SERVER WITH SUFFICENT RESOURCES FOUND");

                    return tempST.serversOfThisType.get(j);

                } /*else {
                    System.out.println("No good servers found");
                    System.out.println("SERVER CORES: " + Integer.toString(tempST.serversOfThisType.get(j).cores));
                    System.out.println("JOB CORES: " + Integer.toString(currentJob.CPU_cores));
                }
            }
            System.out.println("tempST " + tempST.type + "FINISHED, TRYING NEXT...");            
                 */
            }            

        }
        if (firstFitServer == null) {
            firstFitServer = ServerType.getServerCapebleOfRunningJob(currentJob, systemXML_servers).serversOfThisType.get(0);
        }
        return firstFitServer;
    }

    // -------------------------------------//
    // -------- BEST FIT ALGORITHM ---------//
    // -------------------------------------//
    public static Server bestFit() { //BEN FRICKE -45177430

        //    The    fitness    value    of    a    job    to    a    server    is    defined    as    the    difference    between    the    number    of    cores    the    job    requires    and    that    in    the    server
        System.out.println("");
        System.out.println("------- BEST FIT ALGORITHIM ------");
        System.out.println("");

        System.out.println("CURRENT JOB: ");
        System.out.println(currentJob.toString());
        System.out.println("");

        System.out.println("AVAILABLE SERVERS");
        for (Server tempS : servers) {
            System.out.println(tempS.getStringServer());
        }
        System.out.println("");

        System.out.println("SERVERS IN SYSTEM.XML");
        for (ServerType tempST : systemXML_servers) {
            System.out.println(tempST.toString());
        }
        System.out.println("");
        System.out.println("----- END BEST FIT ALGORITHIM -----");
        System.out.println("");

        refreshServerList();

        int bestFit = Integer.MAX_VALUE;
        int minAvail = Integer.MAX_VALUE;
        Server bestFitServer = new Server();

        for (ServerType tempST : systemXML_servers) {            
            for(int j = 0; j < tempST.limit -1; j++) {

                if (tempST.serversOfThisType.get(j).hasResourcesToRunJob(currentJob)) {
                    int fitVal = tempST.serversOfThisType.get(j).calculateFitnessValForJob(currentJob);
                    System.out.println("SERVER WITH SUFFICENT RESOURCES FOUND");
                    if (fitVal < bestFit || (fitVal == bestFit && tempST.serversOfThisType.get(j).available_time < minAvail)) {
                        bestFit = fitVal;
                        minAvail = tempST.serversOfThisType.get(j).available_time;
                        bestFitServer = tempST.serversOfThisType.get(j);
                    }
                } else {
                    System.out.println("No good servers found");
                    System.out.println("SERVER CORES: " + Integer.toString(tempST.serversOfThisType.get(j).cores));
                    System.out.println("JOB CORES: " + Integer.toString(currentJob.CPU_cores));
                }
            }
            System.out.println("tempST " + tempST.type + "FINISHED, TRYING NEXT...");            
        }

        if (bestFit != Integer.MAX_VALUE) {
            return bestFitServer;
        } else {
            //17.    Return    the    best-fit    Active    server    based    on    initial    resource    capacity
            System.out.println("SENDING TO DUMB SERVER");
            //return servers.get(0); //TODO CHANGE THIS
            return ServerType.getServerCapebleOfRunningJob(currentJob, systemXML_servers).serversOfThisType.get(0);
        }    
    }

    // -------------------------------------//
    // -------- WORST FIT ALGORITHM --------//
    // -------------------------------------//
    public static Server worstFit() { //Michael Cavanagh

        System.out.println("========= WORST FIT ALGORITHIM =========");

        //Reset server list in each category of server (type)
        refreshServerList();

        int worstFit = 0;
        int altFit = 0;
        int time = Integer.MAX_VALUE;
        Server worstFitServer = null;
        Server altFitServer = null;

        for (ServerType st : systemXML_servers)
        {
            System.out.println("Searching Server Type: " + st.type);            
            for(int j = 0; j < st.limit -1; j++)
            {
                System.out.println("Testing Server!");
                System.out.println("SERVER CORES = " + Integer.toString(st.serversOfThisType.get(j).cores));
                System.out.println("JOB CORES = " + Integer.toString(currentJob.CPU_cores));
                if (st.serversOfThisType.get(j).hasResourcesToRunJob(currentJob)) //Server has sufficient resources to run job
                {
                    //CALCULATE FITTNESS FOR JOB
                    int fittness = st.serversOfThisType.get(j).calculateFitnessValForJob(currentJob);
                    System.out.println("SERVER FITTNESS = " + fittness);

                    //Check if server is LESS fit to run job AND is available now
                    if (fittness > worstFit && st.serversOfThisType.get(j).state == 2)
                    {
                        System.out.println("New Worst Server Found!");
                        worstFit = fittness;
                        worstFitServer = st.serversOfThisType.get(j);
                    }
                    else if (fittness > altFit || (fittness == altFit && st.serversOfThisType.get(j).available_time < time))
                    {
                        System.out.println("New Alternate Worst Server Found!");
                        altFit = fittness;
                        altFitServer = st.serversOfThisType.get(j);
                        time = st.serversOfThisType.get(j).available_time;
                    }
                }
                else
                {
                    System.out.println("Bad Server!");
                }
            }    
        }

        if (worstFitServer != null)
        {
            System.out.println("Worst Server Found!!!");
            return worstFitServer;
        }
        else if (altFitServer != null)
        {
            System.out.println("Worst Alternate Server Found!!!");
            return altFitServer;
        }
        else
        {
            System.out.println("No Servers Found!!!");
            System.out.println("Sending awwaayyyyyy");
            return ServerType.getServerCapebleOfRunningJob(currentJob, systemXML_servers).serversOfThisType.get(0);
        }
    }

    public static void refreshServerList()
    {
        for (ServerType st : systemXML_servers)
        {
            st.serversOfThisType.clear(); //Clear list

            for (Server s : servers)
            {
                if (s.type.equals(st.type))
                {
                    st.serversOfThisType.add(s); //Fill list with servers
                }     
            }
        }
    }
    public static Server sjf() {

        //    The    fitness    value    of    a    job    to    a    server    is    defined    as    the    difference    between    the    number    of    cores    the    job    requires    and    that    in    the    server
        System.out.println("");
        System.out.println("------- SHORTEST FIT ALGORITHIM ------");
        System.out.println("");

        System.out.println("CURRENT JOB: ");
        System.out.println(currentJob.toString());
        System.out.println("");

        System.out.println("AVAILABLE SERVERS");
        for (Server tempS : servers) {
            System.out.println(tempS.getStringServer());
        }
        System.out.println("");

        System.out.println("SERVERS IN SYSTEM.XML");
        for (ServerType tempST : systemXML_servers) {
            System.out.println(tempST.toString());
        }
        System.out.println("");
        System.out.println("----- END SHORTEST FIT ALGORITHIM -----");
        System.out.println("");

        refreshServerList();

        int minAvail = Integer.MAX_VALUE;
        Server newServer = null;
        Boolean found = false;
        for (ServerType tempST : systemXML_servers) {
            for (int j = 0; j < tempST.limit -1; j++) {
        

        //for (Server tempS : servers) {
            if ((tempST.serversOfThisType.get(j).coreCount >= currentJob.CPU_cores && tempST.serversOfThisType.get(j).memory >= currentJob.memory && tempST.serversOfThisType.get(j).disk >= currentJob.disk && tempST.serversOfThisType.get(j).available_time < minAvail && tempST.serversOfThisType.get(j).state != 4)) {
                // The fitness value of a job to a server is defined as the difference between the number of cores the job requires and that in the server.
                minAvail = tempST.serversOfThisType.get(j).available_time;
                found = true;
                newServer = tempST.serversOfThisType.get(j);
            }
        }
        }


        if (found) {
            return newServer;
        }
        else {
            // We only want to get here if there is nothing calculated above.
            Server servAlt = null;
            for (Server tempS : servers) {
                if (tempST.serversOfThisType.get(j).coreCount >= currentJob.CPU_cores && tempST.serversOfThisType.get(j).disk >= currentJob.disk && tempST.serversOfThisType.get(j).memory >= currentJob.memory) {
                    servAlt = tempST.serversOfThisType.get(j);
                }
            }
            //servAlt.id = 0; // If this isn't zero, server thinks it doesn't exist.
            return servAlt;
        }
    }

    // READS A MESSAGE FROM THE SERVER
    public static String readMsg() throws IOException {
        // final byte[] response = in.readNBytes(in.available()); // Read All Available
        // bytes from socket input stream into
        // byte Array

        // final byte[] response = in.readNBytes(in.available()); // Read All Available
        // bytes from socket input stream into

        final byte[] targetArray = new byte[in.available()];
        in.read(targetArray);
        return new String(targetArray).trim(); // Convert byte array to String and remove leading or trailing whitespaces
    }

    // SENDS A MESSAGE (STRING) TO THE SERVER
    public static void sendMsg(final String msg) throws IOException {
        System.out.println("SENDING: " + msg);

        final String s = msg;
        final byte[] message = s.getBytes();
        out.write(message);
        out.flush();

    }

    // SETS UP SOCKET CONNECTION WITH SERVER NAME & PORT FROM ARGS
    private static void initiliseSocketConnection(final String s, final int p) throws IOException {
        client = new Socket(s, p);
        outToServer = client.getOutputStream();
        out = new DataOutputStream(outToServer);
        inFromServer = client.getInputStream();
        in = new DataInputStream(inFromServer);
    }

    // SETS UP SOCKET CONNECTION WITH SERVER NAME & PORT FROM ARGS
    private static void stopSocketConnection() throws IOException {
        out.flush();
        out.close();
        in.close();
        client.close();
    }

    // Imports Server Data From System.xml into array list of Server Objects 'servers'
    public static void loadSysXML() {
        try {

            // Initiate Input Variables
            final File inputFile = new File("system.xml");
            final DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            final DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            final Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();

            final NodeList nList = doc.getElementsByTagName("server"); // Reads xml where the tag is 'server ' into node
            // list

            for (int temp = 0; temp < nList.getLength(); temp++) { // loop through node list
                final Node nNode = nList.item(temp);

                if (nNode.getNodeType() == Node.ELEMENT_NODE) { // If its an element
                    final Element eElement = (Element) nNode;

                    // ADD SERVER TO LIST WITH PROPERTIES FROM THE XML FILE
                    systemXML_servers.add(new ServerType(eElement.getAttribute(
                            "type"),
                            Integer.parseInt(eElement.getAttribute("limit")),
                            eElement.getAttribute("bootupTime"),
                            eElement.getAttribute("hourlyRate"),
                            Integer.parseInt(eElement.getAttribute("memory")),
                            Integer.parseInt(eElement.getAttribute("disk")),
                            Integer.parseInt((eElement.getAttribute("coreCount")))));
                }
            }    
        } catch (final Exception e) {
            e.printStackTrace(); //Catch errors
        }     
    }

    // LOOPS THROUGH ARRAY OF SERVER OBJECTS TO FIND SERVER WITH MOST CORES (IF MULTIPLE FOUND - RETURNS THE LAST FOUND SERVER)
    // RETURNS: Largest Server In systemXML_servers Array List
    public static ServerType getLargestServerFromSysXML() {

        if (systemXML_servers.isEmpty()) {
            return new ServerType();
        }

        int maxCoreIndex = 0;

        for (int i=0; i<systemXML_servers.size(); i++) //Loop through server list find largest core count
        {
            if (systemXML_servers.get(i).coreCount > systemXML_servers.get(maxCoreIndex).coreCount) {
                maxCoreIndex = i;
            }
        }
        return systemXML_servers.get(maxCoreIndex); //return the largest server
    }
}







