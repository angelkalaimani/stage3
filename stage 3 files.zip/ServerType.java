import java.util.ArrayList;

class ServerType {
	public String type;
	public String bootupTime;
	public String hourlyRate;
	public int limit;
	public Integer coreCount;
	public Integer memory;
	public Integer disk;
	public ArrayList<Server> serversOfThisType = new ArrayList<Server>();
	

	public ServerType(final String t,final int l,final String b,final String h,final Integer m,final Integer d, final Integer c) { //Primary constructor
		type = t;
		limit = l;
		bootupTime = b;
		hourlyRate = h;
		coreCount = c;
		memory = m;
		disk = d;
	}

	public ServerType() { //Blank Constructor
		type = "";
		limit = 0;
		bootupTime = "";
		hourlyRate = "";
		coreCount = 0;
		memory = 0;
		disk = 0;
	}


	public String toString() {
		return type + " LIMIT: " + Integer.toString(limit) + " BOOTUP TIME: " + bootupTime + " HOURLY RATE: " + hourlyRate + " CoreCount: " + Integer.toString(coreCount) + " Memory: " + Integer.toString(memory) + " Disk: " + Integer.toString(disk);
   }

   	public static ServerType getServerCapebleOfRunningJob(Job j, ArrayList<ServerType> systemXML_servers) {
		for (int i=0; i<systemXML_servers.size(); i++) //Loop through server list
		{ 
			if (systemXML_servers.get(i).coreCount >= j.CPU_cores &&
			systemXML_servers.get(i).memory >= j.memory &&
			systemXML_servers.get(i).disk >= j.disk) {
				return systemXML_servers.get(i);
			}
		}
		return new ServerType();
	}
}
